# Pyarmor 9.0.5 (basic), 004829, 2024-11-21T12:07:31.973643
from .pyarmor_runtime import __pyarmor__
